# Week 2: COVID-19 Exploratory Data Analysis
# Run in Google Colab or locally with internet access.
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

url = "https://covid.ourworldindata.org/data/owid-covid-data.csv"
df = pd.read_csv(url, usecols=["location", "date", "total_cases", "total_deaths", "total_vaccinations"])
df["date"] = pd.to_datetime(df["date"], errors="coerce")
df = df.dropna(subset=["location", "date"]).sort_values(["location", "date"])
num_cols = ["total_cases", "total_deaths", "total_vaccinations"]
df[num_cols] = df[num_cols].fillna(0)

world = df[df.location == "World"]
plt.figure(figsize=(12, 6))
sns.lineplot(data=world, x="date", y="total_cases")
plt.title("Global COVID-19: Total Confirmed Cases Over Time")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

aggregates = ["World", "Africa", "Asia", "Europe", "North America", "South America", "Oceania", "European Union", "International"]
countries = df[~df.location.isin(aggregates)]
latest = countries.sort_values("date").groupby("location", as_index=False).tail(1)
top5 = latest.nlargest(5, "total_cases").location.tolist()
sns.lineplot(data=countries[countries.location.isin(top5)], x="date", y="total_cases", hue="location")
plt.title("COVID-19 Total Cases: Top 5 Countries")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

corr = latest[num_cols].corr()
sns.heatmap(corr, annot=True, cmap="coolwarm", vmin=-1, vmax=1)
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.show()

scatter = latest[(latest.total_cases > 0) & (latest.total_deaths > 0)]
sns.scatterplot(data=scatter, x="total_cases", y="total_deaths")
plt.xscale("log"); plt.yscale("log")
plt.title("Total Cases vs Total Deaths by Country")
plt.tight_layout()
plt.show()

latest.to_csv("COVID19_Latest_Country_Summary.csv", index=False)
