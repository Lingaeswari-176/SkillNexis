WEEK 2 — DATA VISUALIZATION
Project: Exploratory Data Analysis on COVID-19 Dataset

Files:
- Week2_COVID19_Exploratory_Data_Analysis.ipynb: notebook with steps and explanations.
- week2_covid_eda.py: standalone Python script.
- This project uses the Our World in Data global COVID-19 CSV URL and downloads data when run.

How to run:
1. Open https://colab.research.google.com/
2. Upload the .ipynb notebook.
3. Run all cells from top to bottom. Internet access is required to download the dataset.
4. Check that all charts appear.
5. If a submission link is required, click Share in Colab and copy the link after setting the access permissions requested by your instructor.

Visualizations: global cases trend line, top-five country comparison, correlation heatmap, and cases-versus-deaths scatter plot.
